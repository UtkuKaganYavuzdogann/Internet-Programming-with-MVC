﻿using System.Data.OleDb;

namespace mvc_hw_3.Helpers
{
    public class Connection
    {
        public OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source= App_Data\hw_3_db.accdb");
        public Connection()
        {
        }

  
    }
}
