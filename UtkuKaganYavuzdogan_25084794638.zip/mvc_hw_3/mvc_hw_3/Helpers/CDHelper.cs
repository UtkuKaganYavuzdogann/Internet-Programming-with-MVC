﻿using mvc_hw_3.Models;
using System.Data.OleDb;

namespace mvc_hw_3.Helpers
{
    public class CDHelper
    {
        private OleDbConnection _connection;

        public CDHelper(OleDbConnection connection)
        {
            _connection = connection;
        }
        public CD CDMapper(OleDbDataReader reader)
        {

            CD cd = new CD
            {
                CDID = Convert.ToInt32(reader["CDID"]),
                Title = reader["Title"].ToString(),
                Artist = reader["Artist"].ToString(),
                Year = Convert.ToInt32(reader["CDYear"]),
                Duration = Convert.ToInt32(reader["Duration"]),
            };
            return cd;

        }

        public CD GetDC(int CDID)
        {
            OleDbCommand cmd = new OleDbCommand("SELECT * FROM CDs WHERE CDID = @id", _connection);
            _connection.Open();
            cmd.Parameters.AddWithValue("@id", CDID);

            OleDbDataReader reader = cmd.ExecuteReader();
            CD cd = new CD();

            while (reader.Read())
            {
                cd = CDMapper(reader);
            }
            reader.Close();
            _connection.Close();
            return cd;
        }


        public List<CD> GetCDs()
        {
            List<CD> cds = new List<CD>();
            OleDbCommand cmd = new OleDbCommand("SELECT * FROM CDs", _connection);
            _connection.Open();
            OleDbDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                cds.Add(CDMapper(reader));
            }
            reader.Close();
            _connection.Close();
            return cds;
        }

        public bool CdInsert(CD cd)
        {
            try
            {
                string query = "INSERT INTO CDs (Title, Artist, CDYear, Duration) VALUES (@Title, @Artist, @CDYear, @Duration)";
                OleDbCommand cmd = new OleDbCommand(query, _connection);
                _connection.Open();

                cmd.Parameters.AddWithValue("@Title", cd.Title);
                cmd.Parameters.AddWithValue("@Artist", cd.Artist);
                cmd.Parameters.AddWithValue("@CDYear", cd.Year);
                cmd.Parameters.AddWithValue("@Duration", cd.Duration);

                cmd.ExecuteNonQuery();
                _connection.Close();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
