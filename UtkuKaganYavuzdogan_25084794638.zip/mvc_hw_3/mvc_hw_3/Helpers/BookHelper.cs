﻿using Microsoft.AspNetCore.Mvc;
using mvc_hw_3.Models;
using System.Data.OleDb;
using System.Net;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using static System.Reflection.Metadata.BlobBuilder;

namespace mvc_hw_3.Helpers
{
    public class BookHelper
    {
        private OleDbConnection _connection;

        public BookHelper(OleDbConnection connection)
        {
            _connection = connection;
        }
        public Book BookMapper(OleDbDataReader reader)
        {

            Book book = new Book
            {
                BookId = Convert.ToInt32(reader["BookId"]),
                Title = reader["Title"].ToString(),
                Author = reader["Author"].ToString(),
                PageNumber = Convert.ToInt32(reader["PageNumber"]),
                Publisher = reader["Publisher"].ToString(),
                CoverImage = reader["CoverImage"].ToString()
            };
            return book;

        }


        public Book GetBook(int BookId)
        {
            OleDbCommand cmd = new OleDbCommand("SELECT * FROM Books WHERE BookId = @id", _connection);
            _connection.Open();
            cmd.Parameters.AddWithValue("@BookId", BookId);

            OleDbDataReader reader = cmd.ExecuteReader();
            Book book = new Book();

            while (reader.Read())
            {
                book = BookMapper(reader);
            }
            reader.Close();
            _connection.Close();
            return book;
        }


        public List<Book> GetBooks()
        {
            List<Book> books = new List<Book>();
            OleDbCommand cmd = new OleDbCommand("SELECT * FROM Books", _connection);
            _connection.Open();
            OleDbDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                books.Add(BookMapper(reader));
            }
            reader.Close();
            _connection.Close();
            return books;
        }
        public bool BookInsert(Book book)
        {
            try
            {
                string query = "INSERT INTO Books(Title, Author, Publisher, PageNumber, CoverImage) VALUES (@Title, @Author, @Publisher, @PageNumber, @CoverImage)";
                OleDbCommand cmd = new OleDbCommand(query, _connection);
                _connection.Open();

                cmd.Parameters.AddWithValue("@Title", book.Title);
                cmd.Parameters.AddWithValue("@Author", book.Author);
                cmd.Parameters.AddWithValue("@Publisher", book.Publisher);
                cmd.Parameters.AddWithValue("@PageNumber", book.PageNumber);
                cmd.Parameters.AddWithValue("@CoverImage", book.CoverImage);

                cmd.ExecuteNonQuery();
                _connection.Close();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }
    }
}
