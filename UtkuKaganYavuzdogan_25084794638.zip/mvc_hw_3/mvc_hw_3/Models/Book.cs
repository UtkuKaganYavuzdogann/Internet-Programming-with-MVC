﻿
namespace mvc_hw_3.Models
{
    public class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Publisher { get; set; }
        public int PageNumber { get; set; } 
        public string CoverImage { get; set; }   

    }
}
