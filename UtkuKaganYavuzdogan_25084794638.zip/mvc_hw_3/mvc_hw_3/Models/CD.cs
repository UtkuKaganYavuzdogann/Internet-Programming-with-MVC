﻿namespace mvc_hw_3.Models
{
    public class CD
    {
        public int CDID { get; set; }
        public string Title { get; set; }
        public string Artist { get; set; }
        public int Year { get; set; }
        public int Duration { get; set; }
    }
}
