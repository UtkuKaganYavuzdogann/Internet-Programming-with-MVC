﻿function getPageInfoList() {
  var storedList = localStorage.getItem("pageInfoList");
  return storedList ? JSON.parse(storedList) : [];
}

var pageTitle = document.title;

var pageLocation = window.location.href;

var pageInfo = {
  title: pageTitle,
  location: pageLocation
};

var pageInfoList = getPageInfoList();


pageInfoList.push(pageInfo);

if (pageInfoList.length > 5) {
  pageInfoList.shift();
}

let pages = getPageInfoList();

let htmlX = '';

for (let i = pages.length-1; i > 0 && i < pages.length; i--) {
  var page = pages[i];
  htmlX += "<li><a href='" + page.location + "'>" + page.title + "</a></li>";
}

document.getElementById("pagesDiv").innerHTML = (htmlX);

localStorage.setItem("pageInfoList", JSON.stringify(pageInfoList));

