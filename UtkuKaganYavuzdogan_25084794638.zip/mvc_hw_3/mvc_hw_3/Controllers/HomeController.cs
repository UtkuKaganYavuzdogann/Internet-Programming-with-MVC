﻿using Microsoft.AspNetCore.Mvc;
using mvc_hw_3.Helpers;

namespace mvc_hw_3.Controllers
{
    public class HomeController : Controller
    {

        private Connection _connection;
        private BookHelper _bookHelper;
        public HomeController()
        {
            _connection = new Connection();
            _bookHelper = new BookHelper(_connection.conn);

        }

        public IActionResult Index()
        {
            ViewData["Title"] = "Home";
            return View();
        }
    }
}
