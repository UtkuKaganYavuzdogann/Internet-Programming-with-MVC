﻿using Microsoft.AspNetCore.Mvc;
using System.Data.OleDb;
using mvc_hw_3.Models;
using mvc_hw_3.Helpers;
using System;
using Microsoft.AspNetCore.Hosting;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.Extensions.Primitives;

namespace mvc_hw_3.Controllers
{
    public class BookController : Controller
    {

        private readonly IWebHostEnvironment _webHostEnvironment;
        private Connection _connection;
        private BookHelper _bookHelper;

        public BookController(IWebHostEnvironment webHostEnvironment)
        {
            _connection = new Connection();
            _bookHelper = new BookHelper(_connection.conn);
            _webHostEnvironment = webHostEnvironment;
        }

        public async Task<IActionResult> Index()
        {
            List<Book> books = _bookHelper.GetBooks();
            if (books != null)
            {
                ViewData["Title"] = "List of All Books";
                return View(books);

            }
            return View(null);
        }

        public IActionResult AddBook()
        {
            ViewData["Title"] = "Add New Book";
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddBook(Book book, IFormFile img)
        {
            try
            {
                if (img != null && img.Length > 0)
                {
                    string imagesPath = Path.Combine(_webHostEnvironment.WebRootPath, "images");
                    string uniqueFileName = Guid.NewGuid().ToString() + "_" + img.FileName;
                    string filePath = Path.Combine(imagesPath, uniqueFileName);
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        img.CopyToAsync(fileStream);
                    }

                    book.CoverImage = $"/Images/{uniqueFileName}";
                }
                _bookHelper.BookInsert(book);
                TempData["SuccessMessage"] = "İşlem başarıyla tamamlandı.";
                return this.Redirect(Url.Action("Index"));
            }
            catch (Exception ex)
            {
                return this.Redirect(Url.Action("AddBook"));
            }
          

        }
        public IActionResult BookDetail(int id)
        {
            Book book = _bookHelper.GetBook(id);
            ViewData["Title"] = book.Title;
            return View(book);
        }

    }
}
