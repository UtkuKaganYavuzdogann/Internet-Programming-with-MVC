﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using mvc_hw_3.Helpers;
using mvc_hw_3.Models;

namespace mvc_hw_3.Controllers
{
    public class CDController : Controller
    {

        private readonly IWebHostEnvironment _webHostEnvironment;
        private Connection _connection;
        private CDHelper _cdHelper;

        public CDController(IWebHostEnvironment webHostEnvironment)
        {
            _connection = new Connection();
            _cdHelper = new CDHelper(_connection.conn);
            _webHostEnvironment = webHostEnvironment;
        }

        public IActionResult Index()
        {
            List<CD> cds = _cdHelper.GetCDs();
            if (cds != null)
            {
                ViewData["Title"] = "List of All CDs";
                return View(cds);

            }
            return View(null);
        }
        public IActionResult AddCD()
        {
            ViewData["Title"] = "Add New CD";
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddCD(CD cd)
        {
            try
            {

                _cdHelper.CdInsert(cd);
                TempData["SuccessMessage"] = "İşlem başarıyla tamamlandı.";
                return this.Redirect(Url.Action("Index"));
            }
            catch (Exception ex)
            {
                return this.Redirect(Url.Action("AddCD"));
            }


        }

        public IActionResult CDDetail(int id)
        {
            CD cd = _cdHelper.GetDC(id);
            ViewData["Title"] = cd.Title;
            return View(cd);
        }
    }
}
